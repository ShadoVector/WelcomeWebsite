cd `dirname $0`
pwd
java -jar ./neaPayCoreProSim.jar