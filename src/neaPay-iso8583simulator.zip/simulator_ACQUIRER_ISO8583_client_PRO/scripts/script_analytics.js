/*
 *   Copyright 
 *               	neaPay.com
 * 		                                contact@neapay.com
 * Registration: neaSoft NL
 * KvK 72447931 Vestigingsnr. 000040557146
 * All rights reserved, all third party software mentioned
 * 
 */
/*
 *                          FREE version
 * The purpose of this version is for learning, peparation, POC, Business Assessment
 * This cannot be used for anything commercial or with financial or business impact.
 * 
 * Free versions are usually BETA tests and have absolutely NO GUARANTEE.
 * 
 * Free versions are NOT tested enough to be used in a production or business-impacting environment.
 * 
 *        Thank you!
 *
 */

var fileExtension = ".html";
var fileNameIncrement = "-" + getDate("YYMMddHHmm");
var isoMessage = copy(ISOMessage);
var line = {
	text: {
		name: "text",
		length_type: "delimited `",
		data_type: "ascii",
		value: ""
	}
}

var transactionCounterANL = 1;// initialize counter;
var divTxArray = [];
var mtiArray = [];
writeAnalyticsHeader();

function writeAnalyticsRow(isoMessage, previousisoMessageRq, testCase) {
	var testCasePass = false;
	var testCaseResultText = "FAIL";

	if (isoMessage.F39_ActionCode.value === testCase.ExpectedRC.value) {
		testCasePass = true
		testCaseResultText = "PASS"
	}
	var analyticsRow = '<div id=\"transaction\" '

	if (testCasePass) {
		analyticsRow = analyticsRow + ' class="alert alert-info"';
	} else {
		analyticsRow = analyticsRow + ' class="alert alert-danger"';
	}

	analyticsRow = analyticsRow + " >"
		+ "<div id =\"transaction_header\" >"
		+ "<button id=\"transaction_button\" class=\"btn btn-primary\" onclick=\"funcShowHide('tx"
		+ transactionCounterANL + "')\">+</button> Test <b>" + testCaseResultText + "</b> " 
		+ " Scenario " + testCase.Scenario.value
		+ " Test# " + testCase.TestNumber.value
		+ " MTI" + isoMessage.MessageType.value + "; " + "STAN:"
		+ isoMessage.F11_SystemTraceAuditNumber.value + "; " + "ProcCode:"
		+ isoMessage.F03_ProcessingCode.value + "; " + "Amount:"
		+ isoMessage.F04_AmountTransaction.value + "; " + "RC:"
		+ isoMessage.F39_ActionCode.value
		+ "; Test case: " + testCase.Scenario.value + " - " + testCase.Description.value
		+ "</div>"
		+ "<div id=\"tx" + transactionCounterANL
		+ "\"   style=\"display:none\">"
		+ " Test case: " + testCase.Scenario.value + " - " + testCase.TestNumber.value + "-" + testCase.Description.value
		+ "<br /> Card: " + testCase.CardID.value
		+ "<div >"
		+ "<b>Message Sent </b>";


	addPassToGraph(testCaseResultText);
	addMtiToGraph(isoMessage.MessageType.value);
	addRcToGraph(isoMessage.F39_ActionCode.value);
	addPcToGraph(isoMessage.F03_ProcessingCode.value);
	addTeToGraph(isoMessage.F11_SystemTraceAuditNumber.value, getResponseTime(isoMessage.F07_TransmissionDateTime.value))

	divTxArray.push("tx" + transactionCounterANL);
	var bitmap = previousisoMessageRq.Bitmap.value;
	for (var ItemName in previousisoMessageRq) {
		if (isBitOn(previousisoMessageRq[ItemName].bitmap_position, getBits(bitmap)))
			analyticsRow = analyticsRow
				+ "       <br/>" + ItemName + ":"
				+ previousisoMessageRq[ItemName].value + ",";
	}
	analyticsRow = analyticsRow + "</div>"
		+ "<div >"
		+ "<b> Message Received </b>";


	var bitmap = isoMessage.Bitmap.value;
	for (var ItemName in isoMessage) {
		if (isBitOn(isoMessage[ItemName].bitmap_position, getBits(bitmap)))
			analyticsRow = analyticsRow
				+ "       <br/>" + ItemName + ":"
				+ isoMessage[ItemName].value + ",";
	}

	analyticsRow = analyticsRow
		+ "</div><div >"
		+ "<br /> Expected RC:" + testCase.ExpectedRC.value
		+ "<br /> Recived RC:" + isoMessage.F39_ActionCode.value;

	analyticsRow = analyticsRow + "<br /> Test "+ testCaseResultText;

	analyticsRow = analyticsRow + "</div></div></div>";
	analyticsRow = analyticsRow
		+ "<script script type=\"text/javascript\">"
		+ "var dataPass=" + getPassData() + ";"
		+ "var dataMTI=" + getMtiData() + ";"
		+ "var dataRC=" + getRcData() + ";"
		+ "var dataPC=" + getPcData() + ";"
		+ "var dataTPS='1';"
		+ "var dataTimeline=" + getTimelineData() + ";"
		+ "var txDivs=" + getDivTxArray() + ";"
		+ "</script>";

	var analyticsRowMessage = line;
	analyticsRowMessage.text.value = analyticsRow;
	send(analyticsRowMessage, AnalyticsFile);
	transactionCounterANL++;

}

function writeAnalyticsRowIss(isoMessage, testCase) {
	var testCasePass = false;
	var testCaseResultText = "FAIL";

	if (isoMessage.F39_ActionCode.value === testCase.F39_ActionCode.value) {
		testCasePass = true
		testCaseResultText = "PASS"
	}
	var analyticsRow = '<div id=\"transaction\" '

	if (testCasePass) {
		analyticsRow = analyticsRow + ' class="alert alert-info"';
	} else {
		analyticsRow = analyticsRow + ' class="alert alert-danger"';
	}
	
	analyticsRow = analyticsRow + " >"
		+ "<div id =\"transaction_header\" >"
		+ "<button id=\"transaction_button\" class=\"btn btn-primary\" onclick=\"funcShowHide('tx"
		+ transactionCounterANL + "')\">+</button>"
		+ "Test Case: " + testCase.ResponseId.value
		+ "; Description: " + testCase.Description.value
		+ "; MTI:" + isoMessage.MessageType.value + "; " + "STAN:"
		+ isoMessage.F11_SystemTraceAuditNumber.value + "; " + "ProcCode:"
		+ isoMessage.F03_ProcessingCode.value + "; " + "Amount:"
		+ isoMessage.F04_AmountTransaction.value + "; " + "RC:"
		+ isoMessage.F39_ActionCode.value
   		+ "; Test case: " + testCase.ResponseId.value + " - " + testCase.Description.value
		+ "</div>"
		+ "<div id=\"tx" + transactionCounterANL
		+ "\"   style=\"display:none\">"
		+ " Test case: " + testCase.ResponseId.value + " - " + testCase.Description.value ;
		+ "<br /> Card: " + testCase.F02_PAN.value
		+ "<div >";

	var pass = false;
	addPassToGraph(testCaseResultText);
	addMtiToGraph(isoMessage.MessageType.value);
	addRcToGraph(isoMessage.F39_ActionCode.value);
	addPcToGraph(isoMessage.F03_ProcessingCode.value);
	addTeToGraph(isoMessage.F11_SystemTraceAuditNumber.value, getResponseTime(isoMessage.F07_TransmissionDateTime.value))

	divTxArray.push("tx" + transactionCounterANL);

	analyticsRow = analyticsRow + "</div>"
		+ "<div >"
		+ "<b> Message Received </b>";


	var bitmap = isoMessage.Bitmap.value;
	for (var ItemName in isoMessage) {
		if (isBitOn(isoMessage[ItemName].bitmap_position, getBits(bitmap)))
			analyticsRow = analyticsRow
				+ "       <br/>" + ItemName + ":"
				+ isoMessage[ItemName].value + ",";
	}

	analyticsRow = analyticsRow
		+ "</div><div >"
		+ "<br /> response Code:" + isoMessage.F39_ActionCode.value;


	analyticsRow = analyticsRow + "<br /> Test "+ testCaseResultText;

	analyticsRow = analyticsRow + "</div></div></div>";
	analyticsRow = analyticsRow
		+ "<script script type=\"text/javascript\">"
		+ "var dataPass=" + getPassData() + ";"
		+ "var dataMTI=" + getMtiData() + ";"
		+ "var dataRC=" + getRcData() + ";"
		+ "var dataPC=" + getPcData() + ";"
		+ "var dataTPS='1';"
		+ "var dataTimeline=" + getTimelineData() + ";"
		+ "var txDivs=" + getDivTxArray() + ";"
		+ "</script>";

	var analyticsRowMessage = line;
	analyticsRowMessage.text.value = analyticsRow;
	send(analyticsRowMessage, AnalyticsFile);
	transactionCounterANL++;

}



function writeAnalyticsHeader() {
	AnalyticsFile.path = AnalyticsFile.path + "-" + fileNameIncrement + fileExtension;
	printLine("ANL: Analytics location:" + AnalyticsFile.path);
	updateConnection(AnalyticsFile);

	resetFile(AnalyticsH);
	clearFile(AnalyticsFile);

	var headerLine = receive(line, AnalyticsH, true);

	while (headerLine != null) {
		send(headerLine, AnalyticsFile);
		headerLine = receive(line, AnalyticsH, true);
	}
}
function writeAnalyticsFooter() {
	var footerLine = " </div>   </body> </html>"
	setVal(line.text, footerLine);
	send(footerLine, AnalyticsFile);
}

function writeAnalyticsRecord() {
	resetFile(AnalyticsH);
	var headerLine = receive(line, AnalyticsH, true);
	while (headerLine != null) {
		send(headerLine.text, AnalyticsFile);
	}
}

function makeAnalytics(messagetodisplay) {
	var bitmap = messagetodisplay.Bitmap.value;
	for (var ItemName in messagetodisplay) {
		if (isBitOn(messagetodisplay[ItemName].bitmap_position, getBits(bitmap)))
			printLine(ItemName + ":" + messagetodisplay[ItemName].value);
	}
}


function getDivTxArray() {
	return JSON.stringify(divTxArray);
}

// ***************************
// Test Pass/Fail mechanism
//
// ***************************
var arrPass = [];
function addPassToGraph(passNew) {
	var id = arrPass.length + 1;
	var found = false;
	for (var i = 0; i < arrPass.length; i++) {
		if (arrPass[i].pass === passNew) {
			arrPass[i].counter++;
			found = true;
			return;
		}
	}
	if (!found) {
		arrPass.push({ id: id, pass: passNew, counter: 1 });
	}
}


function getPassData() {
	var dataPass = [];
	for (var i = 0; i < arrPass.length; i++) {
		dataPass[i] = [];
		dataPass[i][0] = arrPass[i].pass;
		dataPass[i][1] = arrPass[i].counter;

	}
	return JSON.stringify(dataPass);
}


// ***************************
// Message Type mechanism
//
// ***************************
var arrMTI = [];
function addMtiToGraph(mtiNew) {
	var id = arrMTI.length + 1;
	var found = false;
	for (var i = 0; i < arrMTI.length; i++) {
		if (arrMTI[i].mti === mtiNew) {
			arrMTI[i].counter++;
			found = true;
			return;
		}
	}
	if (!found) {
		arrMTI.push({ id: id, mti: mtiNew, counter: 1 });
	}
}


function getMtiData() {
	var dataMTI = [];
	for (var i = 0; i < arrMTI.length; i++) {
		dataMTI[i] = [];
		dataMTI[i][0] = arrMTI[i].mti;
		dataMTI[i][1] = arrMTI[i].counter;
	}
	return JSON.stringify(dataMTI);
}

// ***************************
// Processing Code mechanism
//
// ***************************
var arrPC = [];
function addPcToGraph(pcNew) {
	var id = arrPC.length + 1;
	var found = false;
	for (var i = 0; i < arrPC.length; i++) {
		if (arrPC[i].pc === pcNew) {
			arrPC[i].counter++;
			found = true;
			return;
		}
	}
	if (!found) {
		arrPC.push({ id: id, pc: pcNew, counter: 1 });
	}
}


function getPcData() {
	var dataPC = [];
	for (var i = 0; i < arrPC.length; i++) {
		dataPC[i] = [];
		dataPC[i][0] = arrPC[i].pc;
		dataPC[i][1] = arrPC[i].counter;
	}
	return JSON.stringify(dataPC);
}

// ***************************
// Response Code mechanism
//
// ***************************
var arrRC = [];
function addRcToGraph(rcNew) {
	var id = arrRC.length + 1;
	var found = false;
	for (var i = 0; i < arrRC.length; i++) {
		if (arrRC[i].rc === rcNew) {
			arrRC[i].counter++;
			found = true;
			return;
		}
	}
	if (!found) {
		arrRC.push({ id: id, rc: rcNew, counter: 1 });
	}
}


function getRcData() {
	var dataRC = [];
	for (var i = 0; i < arrRC.length; i++) {
		dataRC[i] = [];
		dataRC[i][0] = arrRC[i].rc;
		dataRC[i][1] = arrRC[i].counter;
	}
	return JSON.stringify(dataRC);
}

// ***************************
// Timeline mechanism
//
// ***************************
var arrTimeline = [];
function addTeToGraph(teNew, tvNew) {
	var id = arrTimeline.length + 1;
	arrTimeline.push({ id: id, te: teNew, tv: tvNew });
}

function getTimelineData() {
	var dataTE = [];
	for (var i = 0; i < arrTimeline.length; i++) {
		dataTE[i] = [];
		dataTE[i][0] = arrTimeline[i].te;
		dataTE[i][1] = parseInt(arrTimeline[i].tv);
	}
	return JSON.stringify(dataTE);
}

