/*
 *   Copyright 
 *               	neaPay.com
 * 		                                contact@neapay.com
 * Registration: neaSoft NL
 * KvK 72447931 Vestigingsnr. 000040557146
 * All rights reserved, all third party software mentioned
 * 
 */
/*
 *                          FREE version
 * The purpose of this version is for learning, peparation, POC, Business Assessment
 * This cannot be used for anything commercial or with financial or business impact.
 * 
 * Free versions are usually BETA tests and have absolutely NO GUARANTEE.
 * 
 * Free versions are NOT tested enough to be used in a production or business-impacting environment.
 * 
 *        Thank you!
 *s
 */

Packages.com.neapay;
var displayInfo = false;
var displayICC = false;
var logBuffer = "";
var displaySetValue = false;



function setFileLogging(value) {
	com.neapay.Functions.setFileLogging(value);
}
function setFileExceptionLogging(value) {
	com.neapay.Functions.setFileExceptionLogging(value);
}
function setTraceTransmission(value) {
	com.neapay.Functions.setTraceTransmission(value);
}
function setTraceConfiguration(value) {
	com.neapay.Functions.setTraceConfiguration(value);
}

function printLine(text) {
	com.neapay.Functions.printLine(text);
}
function showTransactionsMenu(transStringList, functionToCall) {
	com.neapay.Functions.showTransactionsMenu(transStringList, functionToCall);
}

function getBits(string) {
	return com.neapay.Functions.getBits(string);
}

function getChar(string) {
	return com.neapay.Functions.getChar(string);
}
function getBase16(string) {
	return string;// com.neapay.Functions.getBase16(string);
}
function getBase10(string) {
	return string;// com.neapay.Functions.getBase10(string);
}

function xorHex(nr1, nr2) {
	return com.neapay.Functions.xorHex(nr1, nr2);
}

function threedes(block, key1, key2) {
	return com.neapay.Functions.tripleDes(block, key1, key2);
}
function encrypt(block, key) {
	return com.neapay.Functions.encrypt(block, key);
}
function decrypt(block, key) {
	return com.neapay.Functions.decrypt(block, key);
}
function getbits(text) {
	return com.neapay.Functions.getbits(text);
}
function setParity(text, parity) {
	return com.neapay.Functions.setParity(text, parity);
}

function getDate(string) {
	return com.neapay.Functions.getDate(string);
}
function generateArqc(ARQCInputData, ATC, IV, MK, algorythm) {
	return com.neapay.Functions.generateArqc(ARQCInputData, ATC, IV, MK, algorythm);
}
function getRandomInt(min, max) {
	return Math.floor(Math.random() * (max - min)) + min;
}
function generateArpc(ATC, IV, MK, F39, ARQC, PAN, seqNumber, algorythm) {
	printLine('GLO: algor:' + algorythm);
	return com.neapay.Functions.generateArpc(ATC, IV, MK, F39, ARQC, PAN, seqNumber, algorythm);
}
function setOddParity(buffer) {
	return com.neapay.Functions.oddPar(buffer);
}
function saveLog(name) {
	// print('savin loooog' + logBuffer)
	return com.neapay.Functions.saveLog(name, logBuffer);
}
function emvSessionKey(key, atc, iv) {
	return com.neapay.Functions.emvSessionKey(key, atc, iv);
}
function calculate_emv_2000_arqc(cryptogramData, key) {
	return com.neapay.Functions.calculate_emv_2000_arqc(cryptogramData, key);
}
function toBCD(number) {
	return com.neapay.Functions.toBCD(number);
}
function invert(string) {
	return com.neapay.Functions.invert(string);
}

function fromBCD(number) {
	return com.neapay.Functions.fromBCD(number);
}
function bitXOR(text1, text2) {
	return com.neapay.Functions.bitXOR(text1, text2);
}


function receive(message, channel, asJson) {
	var msg = com.neapay.Functions.receive(JSON.stringify(message), JSON.stringify(channel));
	if (asJson === false)
		return msg;
	else
		return JSON.parse(msg);

}

function resetFile(connection) {
	com.neapay.Functions.resetFile(connection.name);
}
function clearFile(connection) {
	com.neapay.Functions.clearFile(connection.name);
}

/*
Sets the value of the ISO field to the provided value, adjusting the format, justification and filling.
*/
function setVal(fieldObject, value) {
	if (displaySetValue)
		printLine('GLO: setVal:' + JSON.stringify(fieldObject) + ' to:' + value);
	fieldObject.value = "";
	fieldObject.value = com.neapay.Functions.setVal(JSON.stringify(fieldObject), value);
	return fieldObject;
}
/*
Sets the ISO value of the field and enables the correct bit in the bitmap
*/
function setValBit(fieldObject, value, bitmap) {
	setVal(fieldObject, value);
	if (bitmap !== undefined)
		if (bitmap.value !== undefined) {
			setVal(bitmap, setBitOn(bitmap.value, fieldObject.bitmap_position));

		}
	return fieldObject;
}

// printJson prints the object
function printJson(object, text) {
	printLine(text + JSON.stringify(object));
}

// printObject prints the keys and the values in the Object, all of them
function printObject(object, text) {
	for (var key in object) {
		printLine(text + key + ':' + object[key].value);
	}
}

function isBitOn(bitmap_position, bitmapParam) {
	if (bitmapParam != undefined)
		var bitmapParam = "0" + bitmapParam;
	else
		bitmapParam = "0" + bitmap;
	// bitmapParam = bitmapParam + ''
	if (bitmapParam.charAt(bitmap_position) == '1') {
		return true;
	} else {
		return false;
	}
}

// PrintMessage lists only the fields that are present in the bitmap, not all of
// them
function printMessage(text, object, charsWidth, align, fill) {
	printLine('-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -');
	var bmp = "0";
	for (var key in object) {
		if (key == "MessageType")
			printLine(text + format(key, charsWidth, align, fill) + ': ' + object[key].value);
		else if (key == "Bitmap") {
			bmp = getBits(object[key].value);
			printLine(text + format(key, charsWidth, align, fill) + ': ' + object[key].value + ' ' + printFields(bmp));
		} else if (key == "Bitmap2") {
			bmp = bmp + getBits(object[key].value);
			printLine(text + format(key, charsWidth, align, fill) + ': ' + object[key].value + " bits:" + bmp);
		} else if ((object[key].bitmap_position == null) || (object[key].bitmap_position == "-1"))
			printLine(text + format(key, charsWidth, align, fill) + ': ' + object[key].value);
		else if (isBitOn(object[key].bitmap_position, bmp))
			printLine(text + format(key, charsWidth, align, fill) + ': ' + object[key].value);
	}
	printLine('-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -');
}
function printFields(bmp) {
	var indices = [];
	for (var i = 0; i < bmp.length; i++) {
		if (bmp[i] == "1") indices.push(i + 1);
	}
	return JSON.stringify(indices);
}
function printAnyMessage(text, object) {
	printLine("GLO: listing all fields below -----------------------------------------");
	for (var key in object) {
		printLine(text + format(key, 30) + ':' + object[key].value);
	}
}

function format(value, length, align, fill) {
	if (length === undefined)
		length = 40;
	if (align === undefined)
		align = "left";
	if (fill === undefined)
		fill = " ";
	if (value.length > length)
		value = value.slice(0, length);
	if (value.length < length)
		if (align == "left")
			while (value.length < length)
				value = value + fill;
		else
			while (value.length < length)
				value = fill + value;
	return value;
}
function sleep(time) {
	printLine("Sleeping "+ time+ "s")
	com.neapay.Functions.sleep(time);
}

function read(message, formatMessage) {
	for (var key in formatMessage) {
		if (formatMessage.hasOwnProperty(key)) {

			formatMessage[key].value = '' + formatMessage[key].value;
		}
	}

	var msg = com.neapay.Functions.read(message, JSON.stringify(formatMessage));
	return JSON.parse(msg);
}

function sendJson(message2, channel2) {
	for (var key in message2) {
		if (message2.hasOwnProperty(key)) {

			message2[key].value = '' + message2[key].value;
		}
	}
	com.neapay.Functions.sendJson(JSON.stringify(message2), JSON.stringify(channel2));
}

function send(msg, connection) {
	if (connection.type == "SQL")
		return com.neapay.Functions.send(msg, sF(connection));
	else
		return com.neapay.Functions.send(sF(msg), sF(connection));
}

function sF(message3) {
	for (var key in message3) {
		if (message3.hasOwnProperty(key)) {
			message3[key].value = '' + message3[key].value;
		}
	}
	return JSON.stringify(message3);
}

function sendReturnBytes(message3, channel3, returnBytes) {
	for (var key in message3) {
		if (message3.hasOwnProperty(key)) {
			message3[key].value = '' + message3[key].value;
		}
	}
	return com.neapay.Functions.send(JSON.stringify(message3), JSON.stringify(channel3), returnBytes);
}
function sendReturnString(message3, channel3, returnBytes) {
	for (var key in message3) {
		if (message3.hasOwnProperty(key)) {
			message3[key].value = '' + message3[key].value;
		}
	}
	return com.neapay.Functions.send(JSON.stringify(message3), JSON.stringify(channel3), returnBytes);
}

function sendTcp(message3, channel3) {
	for (var key in message3) {
		if (message3.hasOwnProperty(key)) {
			message3[key].value = '' + message3[key].value;
		}
	}
	com.neapay.Functions.send(JSON.stringify(message3), JSON.stringify(channel3));
}
function sendFile(message3, channel3) {
	for (var key in message3) {
		if (message3.hasOwnProperty(key)) {
			message3[key].value = '' + message3[key].value;
		}
	}
	com.neapay.Functions.send(JSON.stringify(message3), JSON.stringify(channel3));
}


function sendText(msg, ch) {
	com.neapay.Functions.sendText(msg, JSON.stringify(ch));
}

function listenForIncomingMessages(text) {
	var x = com.neapay.Functions.listenForIncomingMessages(JSON.stringify(isoMessage), JSON.stringify(TCPChannel));
	return JSON.parse(x);
}

function startConnection(connection, message, functionToCall) {
	com.neapay.Functions.startConnection(JSON.stringify(connection), JSON.stringify(message), functionToCall);
}
function stopConnection(connection) {
	com.neapay.Functions.stopConnection(JSON.stringify(connection));
}




function clearValues(message) {
	for (var key in message) {
		message[key].value = "";
	}
}

function isNumeric(n) {
	var isnum = /^\d+$/.test(n);
	return isnum;
}
function setBitOn(bmp, pos) {
	return com.neapay.Functions.setBitOn(bmp, pos);
}
function setBitOff(bmp, pos) {
	return com.neapay.Functions.setBitOff(bmp, pos);
}

function match(pattern, word) {
	return com.neapay.Functions.match(pattern, word);
}
function setTransmissionHeader(header) {
	return com.neapay.Functions.setTransmissionHeader(header);
}
function setTransmissionTrailer(trailer) {
	return com.neapay.Functions.setTransmissionTrailer(trailer);
}
function disableTCPLength() {
	return com.neapay.Functions.disableTCPLength();
}
function runRawLoad(TPS, TCPChannel) {
	return com.neapay.Functions.runRawLoad(TPS, TCPChannel);
}
function runAdvancedLoad(messagesArray, cardsArray, replacementArray, tps, TCPChannel) {
	return com.neapay.Functions.runAdvancedLoad(messagesArray, cardsArray, replacementArray, tps, TCPChannel);
}
function getMessageAsciiLength(message3, channel3) {
	for (var key in message3) {
		if (message3.hasOwnProperty(key)) {
			message3[key].value = '' + message3[key].value;
		}
	}
	return com.neapay.Functions.getMessageAsciiLength(JSON.stringify(message3), JSON.stringify(channel3));
}
function getMessageBytesLength(message3, channel3) {
	for (var key in message3) {
		if (message3.hasOwnProperty(key)) {
			message3[key].value = '' + message3[key].value;
		}
	}
	return com.neapay.Functions.getMessageBytesLength(JSON.stringify(message3), JSON.stringify(channel3));
}
function sha256(message) {
	return com.neapay.Functions.sha256(message);
}
function copy(object) {
	return JSON.parse(JSON.stringify(object))
}
function updateConnection(connectionVar) {
	return com.neapay.Functions.updateConnection(JSON.stringify(connectionVar));
}

function sha256(message) {
	return com.neapay.Functions.sha256(message);
}

function copy(object) {
	return JSON.parse(JSON.stringify(object))
}

function updateConnection(connectionVar) {
	return com.neapay.Functions.updateConnection(JSON.stringify(connectionVar));
}
function setHttpResponseCode(code) {
	return com.neapay.Functions.setHttpResponseCode(code);
}
function setHttpResponseHeader(header) {
	return com.neapay.Functions.setHttpResponseHeader(header);
}
function setHttpResponseData(data) {
	return com.neapay.Functions.setHttpResponseData(data);
}
function executeHttpRequest(method, url, header, body, user, pass) {
	return com.neapay.Functions.executeHttpRequest(method, url, header, body, user, pass, "ntlm");
}
function executeHttpRequestTH(method, url, header, body, user, pass) {
	return com.neapay.Functions.executeHttpRequestTH(method, url, header, body, user, pass, "ntlm");
}
function runLoadHttpTH(TPS, duration, forceDelay) {
	return com.neapay.Functions.runLoadHttpTH(TPS, duration, forceDelay);
}
function startLoadCacheHttp() {
	return com.neapay.Functions.startLoadCacheHttp();
}



function executeSQL(query, channelName) {
	return com.neapay.Functions.executeSQL(query, channelName.name);
}

function startSQLConnection(channelName) {
	com.neapay.Functions.startSQLConnection(channelName.name);
}

function stopSQLConnection(channelName) {
	com.neapay.Functions.stopSQLConnection(channelName.name);
}
function scheduleJobDaily(functionToCall, timeOfDay) {
	// HH:MM
	com.neapay.Functions.scheduleJobDaily(functionToCall, timeOfDay);
}
function scheduleJobMinutely(functionToCall) {
	com.neapay.Functions.scheduleJobMinute(functionToCall, 1, 0);
}
function scheduleJobMinute(functionToCall, minutesInterval, minutesDelay) {
	com.neapay.Functions.scheduleJobMinute(functionToCall, minutesInterval, minutesDelay);
}
function scheduleJobHourly(functionToCall) {
	com.neapay.Functions.scheduleJobHour(functionToCall, 1, 0);
}
function scheduleJobHour(functionToCall, minutesInterval, minutesDelay) {
	com.neapay.Functions.scheduleJobHour(functionToCall, hoursInterval, hoursDelay);
}

function setConnectionTimeout(timeout) {
	com.neapay.Functions.setConnectionTimeout(timeout);
}
function setConnectionKeepAlive(keepAlive) {
	com.neapay.Functions.setConnectionKeepAlive(keepAlive);
}
function des3(text, key, decrypt) {
	return com.neapay.Functions.des3(text, key, decrypt, false);
}
function encryptRSA(block, key) {
	return com.neapay.Functions.encryptRSA(block, key);
}
function decryptRSA(block, key) {
	return com.neapay.Functions.decryptRSA(block, key);
}
function generateRSA(block, key) {
	return com.neapay.Functions.decryptRSA(block, key);
}
function importRSA(block, key) {
	return com.neapay.Functions.decryptRSA(block, key);
}
function byteArrayToHexString(text) {
	return com.neapay.Functions.byteArrayToHexString(text);
}
function hexStringtoByteArray(text) {
	return com.neapay.Functions.hexStringtoByteArray(text);
}
function hexStringToAscii(text) {
	return com.neapay.Functions.hexStringToAscii(text);
}
function isGuiDisabled() {
	return com.neapay.Functions.isGuiDisabled();
}

function clone(objectJson) {
	return JSON.parse(JSON.stringify(objectJson));;
}
function getResponseTime(dateTime){
	// "MMddHHmmss"
	//to 
	//YYYY-MM-DDTHH:MM:SSZ

	var timeNow = new Date();
	var formattedDateTime=timeNow.getFullYear()+"-"+dateTime.substr(0,2)+"-"+dateTime.substr(2,2)+"T"
		+dateTime.substr(4,2)+":"+dateTime.substr(6,2)+":"+dateTime.substr(8,2)+"Z";
	
	var timezoneOffsetMinutes=timeNow.getTimezoneOffset();
	var requestTime=new Date(formattedDateTime);
	
	var elapsedSeconds = Math.floor((timeNow - requestTime -(timezoneOffsetMinutes*60)* 1000)/1000);
	printLine("Response time is "+elapsedSeconds+"s ")
	return elapsedSeconds;
}
