/*
 *   Copyright 
 *               	neaPay.com
 * 		                                contact@neapay.com
 * Registration: neaSoft NL
 * KvK 72447931 Vestigingsnr. 000040557146
 * All rights reserved, all third party software mentioned
 * 
 */
/*
 *                          FREE version
 * The purpose of this version is for learning, peparation, POC, Business Assessment
 * This cannot be used for anything commercial or with financial or business impact.
 * 
 * Free versions are usually BETA tests and have absolutely NO GUARANTEE.
 * 
 * Free versions are NOT tested enough to be used in a production or business-impacting environment.
 * 
 *        Thank you!
 *
 */


// load test cases from the spreadsheet 
var testCasesList = loadTestCases();
// show test cases list and set function to be called when a test case is executed
showTransactionsMenu(testCasesList, "selectedTransaction");

// start a TCP connection
startConnection(TCPChannel, ISOMessage, "processResponse");

// schedule daily regression at 22:55 and minutely echo test
scheduleJobDaily("runRegressionAllTests", "05:20");
// schedule echo test every minute
scheduleJobMinutely("runEchoTest");
//schedule a scenario to run every 10 minutes for a duration test
scheduleJobMinute("runScenarioDuration", 10, 1);

function executeScenario(scenarioName) {
	resetFile(AcquirerDataFile);
	acquirerDataFromCsv = receive(AcquirerData, AcquirerDataFile, true);
	var index = 0;
	while (acquirerDataFromCsv != null) {
		if (acquirerDataFromCsv.Scenario.value === scenarioName &&
			acquirerDataFromCsv.TestReference.value !== "") {

			executeTestCase(acquirerDataFromCsv);
		}
		acquirerDataFromCsv = receive(AcquirerData, AcquirerDataFile, true);
	}
}
function runRegressionAllTests() {
	executeScenario("ISO8583-93");
}
function runEchoTest() {
	executeScenario("EchoTest");
}
function runScenarioDuration() {
	executeScenario("Duration");
}

var isoMessageAcqRq = ISOMessage;
var currentKey = EncryptionData;
var currentCard = CardData;
var currentTestAcquirerDataFromCsv;

function loadTestCases() {
	// building a list for the testCaseStringList menu
	var testCaseStringList = [];
	resetFile(AcquirerDataFile);
	receivedAcquirerDatamessage = receive(AcquirerData, AcquirerDataFile, true);
	var index = 0;
	while (receivedAcquirerDatamessage != null) {
		if (receivedAcquirerDatamessage.Scenario.value !== "Scenario" && receivedAcquirerDatamessage.Scenario.value !== "") {
			testCaseStringList[index] = receivedAcquirerDatamessage.Scenario.value + ' - ' + receivedAcquirerDatamessage.TestNumber.value + ' - ' + receivedAcquirerDatamessage.Description.value;
			index++;
		}
		receivedAcquirerDatamessage = receive(AcquirerData, AcquirerDataFile, true);
	}
	return testCaseStringList;
}
var testsCounter = 0;
var testsCounterPass = 0;
var testsCounterFail = 0;


function processRequest(isoMessageRq) {
	isoMessageRq = JSON.parse(isoMessageRq);
	displayMessage(isoMessageRq);
}

function processResponse(isoMessageRs) {
	//if (loadEnabled)
	//	return; // do not display responses when load mode is enabled
	isoMessageRs = JSON.parse(isoMessageRs);
	displayAcquirerResponse(isoMessageRs);
	var validateResult = true;// validateIsoMessage(isoMessageRs);

	if (validateResult == null) {
		printLine("-  -  -  -  -  -  -  -  VALIDATION FAIL -  -  -  -  -  -  -  -  ");
	}
	if (isoMessageRs.F39_ActionCode.value === currentTestAcquirerDataFromCsv.ExpectedRC.value) {
		printLine("-  -  -  -  -  -  -  -  -  TEST PASS -  -  -  -  -  -  -  -  -  ");
		testsCounterPass++;
	} else {
		printLine("-  -  -  -  -  -  -  -  -  TEST FAIL -  -  -  -  -  -  -  -  -  ");
		testsCounterFail++;
	}


	printLine("RC Received:" + isoMessageRs.F39_ActionCode.value + " RC Expected:" + currentTestAcquirerDataFromCsv.ExpectedRC.value);
	printLine("Tests Executed:" + testsCounter);
	printLine("Tests Passed  :" + testsCounterPass);
	printLine("Tests Failed  :" + testsCounterFail);
	writeAnalyticsRow(isoMessageRs, previousisoMessageAcqRq, currentTestAcquirerDataFromCsv);
	writeCSVLogRow(isoMessageRs, currentTestAcquirerDataFromCsv);

	//if (clearingEnabled == true) {
	//	buildClearingMessage(isoMessageRs);
	//	send(clearingMsg, ClearingFile);
	//}
}
function processResponseLoad(isoMessageRs) {
	isoMessageRs = JSON.parse(isoMessageRs);
	displayAcquirerResponse(isoMessageRs);
}

function displayMessage(messagetodisplay) {
	var bitmap = messagetodisplay.Bitmap.value;
	for (var ItemName in messagetodisplay) {
		if (isBitOn(messagetodisplay[ItemName].bitmap_position, getBits(bitmap)))
			printLine(ItemName + ":" + messagetodisplay[ItemName].value);
	}
}
function displayAcquirerRequest(isoMessageAcqRq) {
	printLine('-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -');
	//printLine('Test case: ' + acquirerDataFromCsv.Scenario.value + ' ' + acquirerDataFromCsv.TestNumber.value + ' ' + acquirerDataFromCsv.Description.value);
	printLine('Card  set: ' + currentCard.CardID.value);
	printLine('Key   set: ' + currentKey.KeyID.value);
	printMessage('', isoMessageAcqRq, 50);
	printLine('-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -');
}

function displayAcquirerResponse(isoMessageAcqRs) {
	printLine('-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -');
	printLine('Message Received');
	printMessage('', isoMessageAcqRs, 50);
	printLine('-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -');
}

// implementation of the function that is called when a transaction is selected
function selectedTransaction(selectedTransactionb, runMode) {
	printLine("Run mode selected : " + runMode + " for : " + selectedTransactionb);
	var transactionListEntry = selectedTransactionb.split(" - ");
	resetFile(AcquirerDataFile);
	acquirerDataFromCsv = AcquirerData;
	acquirerDataFromCsv = receive(acquirerDataFromCsv, AcquirerDataFile, true);
	if (runMode === "RunOne")
		while (acquirerDataFromCsv != null) {

			if (acquirerDataFromCsv.Scenario.value === transactionListEntry[0] &&
				acquirerDataFromCsv.TestNumber.value === transactionListEntry[1] &&
				acquirerDataFromCsv.Description.value === transactionListEntry[2]) {
				executeTestCase(acquirerDataFromCsv);
				return;
			} else
				acquirerDataFromCsv = receive(AcquirerData, AcquirerDataFile, true);
		}
	if (runMode === "RunScenario") {
		while (acquirerDataFromCsv != null) {
			if (acquirerDataFromCsv.Scenario.value === transactionListEntry[0] &&
				acquirerDataFromCsv.TestNumber.value !== "" &&
				acquirerDataFromCsv.Description.value !== "") {

				executeTestCase(acquirerDataFromCsv);
			}
			acquirerDataFromCsv = receive(AcquirerData, AcquirerDataFile, true);
		}
	}
	if (runMode === "RunAll") {
		var msgCounter = 0;
		while (acquirerDataFromCsv != null) {
			if (acquirerDataFromCsv.Scenario.value !== "" && acquirerDataFromCsv.Scenario.value !== "Scenario") {
				executeTestCase(acquirerDataFromCsv);
			}
			acquirerDataFromCsv = receive(AcquirerData, AcquirerDataFile, true);
		}
		printLine("Messages sent:" + msgCounter);
	}
	if (runMode === "RunLoad") {
		setTransmissionTrace(false);
		loadEnabled = true;
		displayInfo = false;
		var msgCounter = 0;
		var startTime = getDate("MM-dd HH:mm:ss:SSS");
		printLine("Load Generation started at:" + startTime + " \nThis UI is now not used, check the Java console. \n Do not close it until you want to stop load generation");

		/*
		 * Raw Load Test (Performance) is a basic load running mechanism
		 * designed to allow simplistic testing It is good enough to test the
		 * raw performance of a simple systems
		 */
		runRawLoad(TPS, "TCPChannel");
		/*
		 * Advanced Load Test (Performance) is the complete load testing
		 * solution that allows switching cards, re-generating hashes, and
		 * updating dynamic data. This Mode needs Advanced configuration.
		 */
		// runAdvancedLoad("", "", "", TPS, "TCPChannel");
	}
}


function executeTestCase(acquirerDataFromCsv) {
	printLine("ACQ: Test case :" + acquirerDataFromCsv.Scenario.value + " - " + acquirerDataFromCsv.TestNumber.value + " - " + acquirerDataFromCsv.Description.value);

	currentTestAcquirerDataFromCsv = acquirerDataFromCsv;

	var cardFound = findCard(acquirerDataFromCsv);
	if (cardFound === 0) {
		printLine("ACQ: Card not found! Processing stopped.");
		return;
	}
	printLine("ACQ: Card record found:" + currentCard.CardID.value + ": " + currentCard.Description.value);

	var keyFound = findKey(acquirerDataFromCsv);
	if (keyFound === 0) {
		printLine("Key not found for:" + acquirerDataFromCsv.EncryptionKey.value);
	}
	printLine("Key found:" + currentKey.KeyID.value + ":" + currentKey.Description.value);

	printLine("ACQ: Building message");
	isoMessageAcqRq = buildAcqRqMessage(acquirerDataFromCsv);
	previousisoMessageAcqRq = isoMessageAcqRq;
	if (displayInfo === true)
		displayAcquirerRequest(isoMessageAcqRq);


	if (acquirerDataFromCsv.PreWait.value !== "**NOVALUE**")
		sleep(acquirerDataFromCsv.PreWait.value);

	// if connection is sync, then receive the response back
	// var isoMessageRs = send(isoMessageAcqRq, TCPChannel);
	// processResponse(isoMessageRs);

	// if connection is async, then just send the message and do not wait; 
	// function processResponse() will be invoked when a message arrives
	send(isoMessageAcqRq, TCPChannel);
	testsCounter++;
}

function buildAcqRqMessage(acquirerDataFromCsv) {
	printLine("Started building message ...");
	isoMessageAcqRq = ISOMessage;
	setVal(isoMessageAcqRq.MessageType, acquirerDataFromCsv.MTI.value);

	bitmap = getBits("0000000000000000");
	for (var key in isoMessageAcqRq) {
		if ((key == "MessageType") || (key == "Bitmap") || (key == "F128_MAC"))
			continue;
		buildField(key, isoMessageAcqRq[key], acquirerDataFromCsv[key], isoMessageAcqRq);
	}
	isoMessageAcqRq.Bitmap.value = getChar(bitmap);
	return isoMessageAcqRq
}


function buildField(name, field, caseField, isoMessageAcqRq) {
	if (displaySetValue)
		printLine("Populate " + name + " with " + caseField.value);
	if (caseField.value == "**NOVALUE**") {
		return;
	} else if (caseField.value == "**PREV_RQST**") {
		if (previousisoMessageAcqRq[name].value == "") {
			printLine("Cannot use PREV_RQST for field:" + name + " because it has the previous request");
			return;
		}
		setVal(field, isoMessageAcqRq[name].value)
	} else if (caseField.value == "**SYSTEM**") {
		setVal(field, buildSystemField(name, field, caseField));
	} else if (caseField.value == "**CARDFILE**") {
		setVal(field, buildCardField(name, field, currentCard));
	} else if (caseField.value == "**TERMFILE**") {
		setVal(field, buildTermField(name, field, currentTerm));
	} else {
		setVal(field, caseField.value);
	}
	setBitON(field.bitmap_position);
}

function buildCardField(name, field, currentCard) {
	if (name == "F14_DateExpiration") {
		return currentCard.ExpiryDate.value;
	} else if (name == "F17_DateCapture") {
		return currentCard.DateCapture.value;
	} else
		printLine("ISS: CARD Field not populated:" + name);
}
function buildTermField(name, field, currentTerm) {
	if (name == "F18_MerchantType") {
		return currentTerm.MerchantType.value;
	} else if (name == "F19_AcquiringInstitutionCountryCode") {
		return currentTerm.AcquiringInstitutionCountryCode.value;
	} else
		printLine("ISS: TERM Field not populated:" + name);
}

function buildSystemField(name, field, caseField) {
	//printLine("ISS: Field name:"+name);
	if (name == "F07_TransmissionDateTime") {
		return getDate("MMddHHmmss");
	} else if (name == "F11_SystemTraceAuditNumber") {
		return getSTAN();
	} else if (name == "F12_DateTimeLocalTransaction") {
		return getDate("YYMMddhhmmss");
	} else if (name == "F13_DateLocalTxn") {
		return getDate("MMdd");
	} else if (name == "F14_DateExpiration") {
		return currentCard.ExpiryDate.value;
	} else if (name == "F15_DateSettlement") {
		return getDate("MMdd");
	} else if (name == "F35_Track2Data") {
		var track2Data = currentCard.PAN.value + "=";
		if (currentCard.ExpiryDate.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.ExpiryDate.value;
		if (currentCard.ServiceCode.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.ServiceCode.value;
		if (currentCard.Pvki.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.Pvki.value;
		if (currentCard.Pvv.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.Pvv.value;
		if (currentCard.Cvv.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.Cvv.value;
		if (currentCard.CardSeqNbr.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.CardSeqNbr.value;
		return track2Data;
	} else if (name == "F37_RetrievalReferenceNumber") {
		return getDate("mmss") + getRRN();

	} else if (name == "F52_PINData") {
		var pinNumber = currentCard.PIN.value;
		var pbFormat = currentCard.PBFormat.value;
		var PBlock1 = "";
		var PBlock2 = "";
		var PINBlock = "";
		if (pbFormat === "**ISO-0**")
			PBlock1 = "0" + pinNumber.length + pinNumber;
		else if (pbFormat === "**ISO-1**")
			PBlock1 = "1" + pinNumber.length + pinNumber;
		else if (pbFormat === "**PINPAD**")
			PBlock1 = pinNumber;
		else
			printLine("PIN Block format unrecognized");

		if (pbFormat === "**ISO-0**" || pbFormat === "**PINPAD**")
			PBlock1 = (PBlock1 + "FFFFFFFFFFFFFFFF").slice(0, 16);
		else
			PBlock1 = (PBlock1 + "0000000000000000").slice(0, 16);

		var pan = currentCard.PAN.value;
		var panLen = pan.length;
		PBlock2 = "0000" + pan.slice(panLen - 13, panLen - 1);
		if (pbFormat === "**ISO-0**")
			PINBlock = xorHex(PBlock1, PBlock2);
		else
			PINBlock = PBlock1;

		var PINBlock = threedes(PINBlock, currentKey.PPKPartOne.value, currentKey.PPKPartTwo.value)
		return PINBlock;
	} else if (name == "F128_MAC") {
		return build_Mac(isoMessageAcqRq);
	} else
		printLine("ISS: System Field not populated:" + name);
}



function findCard(acquirerDataFromCsv) {
	var search = 0
	resetFile(CardDataFile);
	//printLine('ACQ:Looking for card:' + acquirerDataFromCsv.CardID.value);
	var CardData1 = receive(CardData, CardDataFile, true);
	// printLine('acquirerDataFromCsv.CardID.value:' +
	// acquirerDataFromCsv.CardID.value)
	// printLine('CardData1.CardID.value :' + CardData1.CardID.value)
	while ((search === 0) && (CardData1 != null)) {

		// printLine('acquirerDataFromCsv.CardID.value:' +
		// acquirerDataFromCsv.CardID.value)
		// printLine('CardData1.CardID.value :' + CardData1.CardID.value)
		if (acquirerDataFromCsv.CardID.value === CardData1.CardID.value) {
			currentCard = CardData1;
			return 1;
		}
		CardData1 = receive(CardData, CardDataFile, true);
	}
}
function findTerminal(acquirerDataFromCsv) {
	var search = 0
	resetFile(TerminalDataFile);
	//printLine('Looking for Terminal:' + acquirerDataFromCsv.TerminalID.value);
	var TerminalData1 = receive(TerminalData, TerminalDataFile, true);
	while ((search === 0) && (TerminalData1 != null)) {

		if (acquirerDataFromCsv.TerminalID.value === TerminalData1.TerminalID.value) {
			currentTerminal = TerminalData1
			search = 1
		}
		TerminalData1 = receive(TerminalData, TerminalDataFile, true);
	}
}

function findKey(acquirerDataFromCsv) {
	var search = 0;
	resetFile(EncryptionDataFile);
	//printLine('Looking for Key:' + acquirerDataFromCsv.EncryptionKey.value);
	var EncryptionData1 = receive(EncryptionData, EncryptionDataFile, true);
	while ((search === 0) && (EncryptionData1 != null)) {
		if (acquirerDataFromCsv.EncryptionKey.value === EncryptionData1.KeyID.value) {
			currentKey = EncryptionData1;
			search = 1;
		}
		EncryptionData1 = receive(EncryptionData, EncryptionDataFile, true);
	}
}

function setBitON(bitmap_position) {
	// bitmap starts from position 0, which must always be zero.
	// 01000010 - counting from the left, the second and seventh bits are 1,
	// indicating that fields 2 and 7 are present)
	if (!isNumeric(bitmap_position)) {
		printLine('error activating bitmap bit:' + bitmap_position)
		return;
	}
	if (bitmap_position > bitmap.length) {
		setBitON(isoMessageAcqRq.Bitmap.bitmap_position);
		bitmap = bitmap + getBits("0000000000000000");
	}
	// printLine('ACQ- activate bitmap:' + bitmap_position + '=>' + bitmap)
	bitmap = bitmap.substring(0, bitmap_position - 1) + '1' + bitmap.substring(bitmap_position)
	// printLine('bitmap update:'+bitmap)
}

function getRRN() {
	var RRN = 0;
	resetFile(DynamicDataFile);
	var DynamicData1 = receive(DynamicData, DynamicDataFile, true);
	if (DynamicData1 != null) {
		RRN = DynamicData1.ReferenceNumber.value;
		RRN = parseInt(RRN, 10);
	} else {
		DynamicData1 = DynamicData;
	}

	RRN++;
	setVal(DynamicData1.ReferenceNumber, RRN);
	clearFile(DynamicDataFile);
	send(DynamicData1, DynamicDataFile);
	return RRN;
}

function getSTAN() {
	var traceNumber = 0;
	resetFile(DynamicDataFile);
	var DynamicData1 = receive(DynamicData, DynamicDataFile, true);
	if (DynamicData1 != null) {
		traceNumber = DynamicData1.STAN.value;
		traceNumber = parseInt(traceNumber, 10);
	} else {
		DynamicData1 = DynamicData;
	}

	traceNumber++;
	setVal(DynamicData1.STAN, traceNumber);
	clearFile(DynamicDataFile);
	send(DynamicData1, DynamicDataFile);
	return traceNumber;
}

function validateIsoMessage(isoMessageIssRs) {
	resetFile(ValidationDataFile);

	bitmapIss = getBits(isoMessageIssRs.Bitmap.value);
	var MTI = isoMessageIssRs.MessageType.value;
	var search = 0;
	// skip 2 lines of header
	var validationDataFromCsv;
	validationDataFromCsv = receive(ValidationMsg, ValidationDataFile, true);
	validationDataFromCsv = receive(ValidationMsg, ValidationDataFile, true);
	// read 2 lines of length and numeric check
	var validationLengths = receive(ValidationMsg, ValidationDataFile, true);
	var validationNumeric = receive(ValidationMsg, ValidationDataFile, true);
	var validationFields = ""

	while ((search == "0") && (validationDataFromCsv != null)) {
		if (MTI === validationDataFromCsv.MTI.value) {
			search = "1"
			validationFields = validationDataFromCsv
		}
		validationDataFromCsv = receive(ValidationMsg, ValidationDataFile, true);
	}

	if (search == "0") {
		printLine("Unable to validate inbound message with MTI:" + MTI)
		return;
	}

	// we have the validation data loaded, performing the checks for length and
	// numeric
	for (var itemKey in isoMessageIssRs) {
		if (('bitmap_position' in isoMessageIssRs[itemKey]) && (isBitOn(isoMessageIssRs[itemKey].bitmap_position, bitmapIss))) {
			var value = isoMessageIssRs[itemKey].value
			// printLine('ACQ:' + itemKey + ':' +
			// isoMessageIssRs[itemKey].value)
			// printLine(itemKey + ':' + isoMessageIssRs[itemKey].value.length)

			// validating field lengths
			if (itemKey in validationLengths) {
				if (value.length !== validationLengths[itemKey].value)
					printLine('Validation error: field ' + itemKey + ' has a length of ' + value.length + ', but expected ' + validationLengths[itemKey].value + ':[' + value
						+ ']')
				// printLine(itemKey + ':' +
				// validationLengths[itemKey].value)
				// printLine(itemKey + ':' +
				// validationNumeric[itemKey].value)
				// printLine(itemKey + ':' +
				// validationFields[itemKey].value)
			} else
				printLine('Warning: could not validate field:' + itemKey + '.It was not found in the lengths validation message!')

			// validating fields for numeric values
			if (itemKey in validationNumeric) {

				if ((!isNumeric(value)) && (validationNumeric[itemKey].value === 'Y'))
					printLine('Validation error: field ' + itemKey + ' is expected to be numeric, but is not :[' + value + ']')
				// printLine(itemKey + ':' +
				// validationLengths[itemKey].value)
				// printLine(itemKey + ':' +
				// validationNumeric[itemKey].value)
				// printLine(itemKey + ':' +
				// validationFields[itemKey].value)
			} else
				printLine('Warning: could not validate field:' + itemKey + '.It was not found in the numeric validation message!')
		}

		// validating fields presence, iterating through ISO fields, which match
		// the Validation message fields (keys match)
		// Validate only the ones that start with F
		if ((itemKey.charAt(0) === 'F') && (itemKey in validationFields)) {

			// printLine('key:' + itemKey)
			var requiredField = validationFields[itemKey].value
			// this will be M if required
			// printLine('' + itemKey + ':' +
			// isoMessageIssRs[itemKey].value)
			if (requiredField === 'M') {
				if (isoMessageIssRs[itemKey].value === "")
					printLine('Validation error: mandatory field ' + itemKey + ' missing')
			}
			if (requiredField === 'I') {
				if (isoMessageIssRs[itemKey].value !== "")
					printLine('Validation error: field ' + itemKey + ' is present and it should not be: ' + isoMessageIssRs[itemKey].value)
			}
			if (requiredField === 'E') {
				if ((itemKey in previousIsoMessage) && (previousIsoMessage[itemKey].value !== ""))
					if (previousIsoMessage[itemKey].value !== isoMessageIssRs[itemKey].value)
						printLine('Validation error: field ' + itemKey + ' should be echo of the previous request:' + previousIsoMessage[itemKey].value)
			}
			if (requiredField === 'A') {
				if (!validateConditional(itemKey, isoMessageIssRs, 'ISS', currentCard))
					printLine('Validation error: conditional field validation failed')
			}
		}

	}

}

function build_F35_Track2Data(acquirerDataFromCsv) {
	if (acquirerDataFromCsv.F35_Track2Data.value === "**NOVALUE**") {
		return;
	} else if (acquirerDataFromCsv.F35_Track2Data.value === "**PREV_RQST**")
		setVal(isoMessageAcqRq.F35_Track2Data, previousisoMessageAcqRq.F35_Track2Data.value);
	else if (acquirerDataFromCsv.F35_Track2Data.value === "**SYSTEM**") {
		var track2Data = currentCard.PAN.value + "=";
		if (currentCard.ExpiryDate.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.ExpiryDate.value;
		if (currentCard.ServiceCode.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.ServiceCode.value;
		if (currentCard.Pvki.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.Pvki.value;
		if (currentCard.Pvv.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.Pvv.value;
		if (currentCard.Cvv.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.Cvv.value;
		if (currentCard.CardSeqNbr.value !== "**NOVALUE**")
			track2Data = track2Data + currentCard.CardSeqNbr.value;
		setVal(isoMessageAcqRq.F35_Track2Data, track2Data);
	} else
		setVal(isoMessageAcqRq.F35_Track2Data, acquirerDataFromCsv.F35_Track2Data.value);
	setBitON(isoMessageAcqRq.F35_Track2Data.bitmap_position)
}


// build_F52_PINData(acquirerDataFromCsv);
function build_F52_PINData(acquirerDataFromCsv) {
	if (acquirerDataFromCsv.F52_PINData.value === "**NOVALUE**") {
		return;
	} else if (acquirerDataFromCsv.F52_PINData.value === "**PREV_RQST**")
		setVal(isoMessageAcqRq.F52_PINData, previousisoMessageAcqRq.F52_PINData.value);
	else if (acquirerDataFromCsv.F52_PINData.value === "**CARDFILE**")
		setVal(isoMessageAcqRq.F52_PINData, currentTerminal.F52_PINData.value);
	else if (acquirerDataFromCsv.F52_PINData.value === "**SYSTEM**") {

		var pinNumber = currentCard.PIN.value;
		var pbFormat = currentCard.PBFormat.value;
		var PBlock1 = "";
		var PBlock2 = "";
		var PINBlock = "";
		if (pbFormat === "**ISO-0**")
			PBlock1 = "0" + pinNumber.length + pinNumber;
		else if (pbFormat === "**ISO-1**")
			PBlock1 = "1" + pinNumber.length + pinNumber;
		else if (pbFormat === "**PINPAD**")
			PBlock1 = pinNumber;
		else
			printLine("PIN Block format unrecognized");

		if (pbFormat === "**ISO-0**" || pbFormat === "**PINPAD**")
			PBlock1 = (PBlock1 + "FFFFFFFFFFFFFFFF").slice(0, 16);
		else
			PBlock1 = (PBlock1 + "0000000000000000").slice(0, 16);

		var pan = currentCard.PAN.value;
		var panLen = pan.length;
		PBlock2 = "0000" + pan.slice(panLen - 13, panLen - 1);
		if (pbFormat === "**ISO-0**")
			PINBlock = xorHex(PBlock1, PBlock2);
		else
			PINBlock = PBlock1;

		var PINBlock = threedes(PINBlock, currentKey.PPKPartOne.value, currentKey.PPKPartTwo.value)
		setVal(isoMessageAcqRq.F52_PINData, PINBlock)

	} else
		setVal(isoMessageAcqRq.F52_PINData, acquirerDataFromCsv.F52_PINData.value);
	setBitON(isoMessageAcqRq.F52_PINData.bitmap_position)
}


// build_F55_ICCData(acquirerDataFromCsv);
function build_F55_ICCData(acquirerDataFromCsv) {
	if (acquirerDataFromCsv.F55_ICCData.value === "**NOVALUE**") {
		return;
	} else if (acquirerDataFromCsv.F55_ICCData.value === "**PREV_RQST**")
		setVal(isoMessageAcqRq.F55_ICCData, previousisoMessageAcqRq.F52_PINData.value)
	else if (acquirerDataFromCsv.F55_ICCData.value === "**CARDFILE**")
		setVal(isoMessageAcqRq.F55_ICCData, currentTerminal.F52_PINData.value)
	else if (acquirerDataFromCsv.F55_ICCData.value === "**SYSTEM**") {

		/*
		 * The following are derived from the script : 9F26 - Cryptogram
		 * (Mandatory) 9F27 - Cryptogram Data (Mandatory) 5F2A - Txn Cncy Code
		 * (Mandatory) 9C - Txn Type (Mandatory) 9A - Date (Mandatory) 9F37 - UN
		 * (Mandatory) 9F36 - Appl Txn Counter (Mandatory) 9F03 - Amt Other
		 * (Optional)
		 */

		/*
		 * The following are derived from the card: 82 - Appl Interchange
		 * Profile (Mandatory) 9F10 - Issuer Appl Data (Mandatory) 9F34 - CVM
		 * (Optional) 9F09 - Appl Version Number (Optional)
		 */

		/*
		 * The following are derived from the device: 9F1A - Terminal Cntry Code
		 * (Mandatory) 9F33 - Terminal Capabilities (Optional) 9F35 - Terminal
		 * Type (Optional) 9F1E - Device Serial Number (Optional) 95 - TVR
		 * (Mandatory)
		 */

		if ((acquirerDataFromCsv.F55_ICCData.value === "**NOVALUE**") // E2022
			|| (acquirerDataFromCsv.F55_82.value === "**NOVALUE**") || (acquirerDataFromCsv.F55_9F10.value === "**NOVALUE**")
			|| (acquirerDataFromCsv.F55_9F1A.value === "**NOVALUE**") || (acquirerDataFromCsv.F55_95.value === "**NOVALUE**")
			|| (acquirerDataFromCsv.F55_9F27.value === "**NOVALUE**")) {
			printLine('ERROR: Not all mandatory EMV tags are present, cannot build cryptogram. TAGS (82, 9F10, 9F1A, 95, 9F27) must be present for EMV')
		}

		var cryptogram = Cryptogram;
		clearValues(cryptogram);
		cryptogram = buildCryptogram(acquirerDataFromCsv, cryptogram);
		printLine("Gen ARQC:" + cryptogram.GeneratedArqc.value);

		// var number="000000003900";
		// var numBCD=toBCD(number)
		// printLine('numBCD:'+numBCD)
		// var numInit = fromBCD(numBCD)
		// printLine('numInit'+numInit)
		setVal(isoMessageAcqRq.F55_ICCData, buildICCdata(acquirerDataFromCsv, cryptogram))

	} else
		setVal(isoMessageAcqRq.F55_ICCData, acquirerDataFromCsv.F55_ICCData.value);
	setBitON(isoMessageAcqRq.F55_ICCData.bitmap_position)
	// printLine('F55_ICCData:' + isoMessageAcqRq.F55_ICCData.value)
}
function buildICCdata(acquirerDataFromCsv, cryptogram) {
	// When the length defined for the data object is greater than the length of
	// the actual data, the following rules apply:
	// A data element in format n is right justified and padded with leading
	// hexadecimal zeroes.
	// A data element in format cn is left justified and padded with trailing
	// hexadecimal 'F's.
	// A data element in format a, an, or ans is left justified and padded with
	// trailing hexadecimal zeroes.
	// When data is moved from one entity to another (for example, card to
	// terminal), it shall always be passed in order from high order to low
	// order, regardless of how it is internally stored. The same rule applies
	// when concatenating data.
	// Note: Data that can occur in template '70' or '77' can never occur in
	// both.
	//		
	var returnString = "";
	returnString = "";
	returnString = returnString + "9F0206" + cryptogram.Amount.value;
	returnString = returnString + "9F0306" + cryptogram.AmountOther.value;
	returnString = returnString + "9F1A02" + cryptogram.CtryCode.value;
	returnString = returnString + "9505" + cryptogram.TVR.value;
	returnString = returnString + "5F2A02" + cryptogram.CncyCode.value;
	returnString = returnString + "9A03" + cryptogram.TxnDate.value;
	returnString = returnString + "9C01" + cryptogram.TxnType.value;
	returnString = returnString + "9F3704" + cryptogram.UN.value;
	returnString = returnString + "8202" + cryptogram.AIP.value;
	returnString = returnString + "9F3602" + cryptogram.ATC.value;

	// MasterCard format of the Issuer Application Data (9F10)
	// Derivation Key Index, (1 Byte)
	// Cryptogram Version Nbr, (1 Byte)
	// CVR, 4 bytes
	// DAC, 2 bytes.

	var len = acquirerDataFromCsv.F55_9F10.value.length;
	len = len / 2;
	var hexLen = {
		"length_type": "fixed 1",
		"data_type": "hex"
	}
	setVal(hexLen, len);
	// printLine('9f10 value and len:' + acquirerDataFromCsv.F55_9F10.value
	// +
	// ":"
	// + len + ",hex len:" + hexLen.value)
	printLine("length 9F10 here:" + len)
	returnString = returnString + "9F10" + hexLen.value + acquirerDataFromCsv.F55_9F10.value
	printLine("9f10 value:" + acquirerDataFromCsv.F55_9F10.value)

	returnString = returnString + "9F2608" + cryptogram.GeneratedArqc.value
	returnString = returnString + "9F2701" + acquirerDataFromCsv.F55_9F27.value

	if (acquirerDataFromCsv.F55_9F09.value !== "**NOVALUE**")
		returnString = returnString + "9F0902" + acquirerDataFromCsv.F55_9F09.value;
	if (acquirerDataFromCsv.F55_9F1E.value !== "**NOVALUE**")
		returnString = returnString + "9F1E08" + acquirerDataFromCsv.F55_9F1E.value;
	if (acquirerDataFromCsv.F55_9F33.value !== "**NOVALUE**")
		returnString = returnString + "9F3303" + acquirerDataFromCsv.F55_9F33.value;
	if (acquirerDataFromCsv.F55_9F34.value !== "**NOVALUE**")
		returnString = returnString + "9F3403" + acquirerDataFromCsv.F55_9F34.value;
	if (acquirerDataFromCsv.F55_9F35.value !== "**NOVALUE**")
		returnString = returnString + "9F3501" + acquirerDataFromCsv.F55_9F35.value;

	return returnString;

}

function buildCryptogram(acquirerDataFromCsv, cryptogramData) {
	var arqc = ""
	var TimeNow = getDate("HH:mm:ss")
	// No cryptogram version number.
	if (currentCard.EMVStandard.value == "**NOVALUE**") {
		printLine("| ERROR : NO EMV LEVEL")
		return;
	}

	// No card sequence number.
	if ((isoMessageAcqRq.F23_CardSequenceNumber.value === "") && (isBitOn(isoMessageAcqRq.F23_CardSequenceNumber.bitmap_position, bitmap))) {
		printLine("| ERROR : " + TimeNow + " EMV - No Card Seq Nbr");
		return;
	} else if (!isNumeric(isoMessageAcqRq.F23_CardSequenceNumber.value)) {
		printLine("| ERROR : " + TimeNow + " EMV - Card Seq Nbr is not numeric");
		return;
	}

	// No amount.
	if (acquirerDataFromCsv.F55_9F02.value === "**NOVALUE**") {
		printLine("| ERROR : " + TimeNow + " EMV - No Transaction Amount");
		return;
	} else if ((acquirerDataFromCsv.F55_9F02.value !== "") && (!isNumeric(acquirerDataFromCsv.F55_9F02.value))) {
		printLine("| ERROR : " + TimeNow + " EMV - Transaction Amount is not numeric:" + acquirerDataFromCsv.F55_9F02.value);
		return;
	}

	// No pan.
	if ((isoMessageAcqRq.F02_PAN.value === "") && (isoMessageAcqRq.F35_Track2Data.value === "") && (isoMessageAcqRq.F45_Track1Data.value === "")) {
		printLine("| ERROR : " + TimeNow + " EMV - No F2/F35/F45");

		return;
	}

	if (isoMessageAcqRq.F02_PAN.value !== "") {
		if (!isNumeric(isoMessageAcqRq.F02_PAN.value)) {
			printLine("| ERROR : " + TimeNow + " F2 Not numeric");
			return;
		}

		cryptogramData.PAN.value = isoMessageAcqRq.F02_PAN.value
	}

	else if (isoMessageAcqRq.F35_Track2Data.value !== "") {
		var Pos = isoMessageAcqRq.F35_Track2Data.value.indexOf('=');
		if (Pos !== 0)
			cryptogramData.PAN.value = isoMessageAcqRq.F35_Track2Data.value.slice(0, Pos - 1);
		else {
			// Cannot determine pan - looks like an invalid track 2.
			printLine("| ERROR : Cannot determine pan - looks like an invalid track  2 " + cryptogramData.PAN.value);
			return;
		}
	}

	else {
		var Pos = isoMessageAcqRq.F45_Track1Data.indexOf('=');
		if (Pos !== 0)
			cryptogramData.PAN.value = isoMessageAcqRq.F45_Track1Data.value.slice(0, Pos - 1);
		else {
			// Cannot determine pan - looks like an invalid track 3.
			printLine("| ERROR : Cannot determine pan - looks like an invalid track	 1	 " + cryptogramData.PAN.value);
			return;
		}
	}

	// No Country Code.
	if (acquirerDataFromCsv.F55_9F1A.value === "**NOVALUE**") {
		printLine("| ERROR : " + TimeNow + " EMV - No Country Code 9F1A");
		return;
	} else if (!isNumeric(acquirerDataFromCsv.F55_9F1A.value)) {
		printLine("| ERROR : " + TimeNow + " EMV - Country Code 9F1A is not numeric:" + acquirerDataFromCsv.F55_9F1A.value);
		return;
	}

	// Terminal Verification Result.
	if (acquirerDataFromCsv.F55_95.value === "**NOVALUE**") {
		printLine("| ERROR : ", TimeNow, " EMV - No Terminal Verification 	 Result	 95");
		return;
	}

	// Application Interchange Profile.
	if (acquirerDataFromCsv.F55_82.value === "**NOVALUE**") {
		printLine("| ERROR : ", TimeNow, " EMV - No Application Interchange 	 Profile	 82");
		return;
	}

	// Transaction Currency Code
	if (acquirerDataFromCsv.F55_5F2A.value === "**NOVALUE**") {
		printLine("| ERROR : ", TimeNow, " EMV - No Transaction Currency Code	 5F2A");
		return;
	}

	// ---------------------------------------------------
	// Card Sequence Number
	// ---------------------------------------------------
	setVal(cryptogramData.PanSequenceNumber, isoMessageAcqRq.F23_CardSequenceNumber.value);
	// ---------------------------------------------------
	// 9F02
	// ---------------------------------------------------
	// cryptogramData.Amount.value =
	setVal(cryptogramData.Amount, acquirerDataFromCsv.F55_9F02.value);
	// ---------------------------------------------------
	// 9F03
	// ---------------------------------------------------
	setVal(cryptogramData.AmountOther, acquirerDataFromCsv.F55_9F03.value);
	// ---------------------------------------------------
	// 9F1A
	// ---------------------------------------------------
	setVal(cryptogramData.CtryCode, acquirerDataFromCsv.F55_9F1A.value);

	// ---------------------------------------------------
	// 95
	// ---------------------------------------------------
	setVal(cryptogramData.TVR, acquirerDataFromCsv.F55_95.value);

	// ---------------------------------------------------
	// 5F2A
	// ---------------------------------------------------
	setVal(cryptogramData.CncyCode, acquirerDataFromCsv.F55_5F2A.value);

	// ---------------------------------------------------
	// 9A
	// ---------------------------------------------------
	setVal(cryptogramData.TxnDate, getDate("YYMMdd"));

	// ---------------------------------------------------
	// 9C
	// ---------------------------------------------------
	if (isoMessageAcqRq.F03_ProcessingCode.value.slice(0, 2) === "01")
		setVal(cryptogramData.TxnType, "01");
	else
		setVal(cryptogramData.TxnType, "00");

	// ---------------------------------------------------
	// 9F37
	// ---------------------------------------------------
	setVal(cryptogramData.UN, getDate("mmss"));

	// ---------------------------------------------------
	// 82
	// ---------------------------------------------------
	setVal(cryptogramData.AIP, acquirerDataFromCsv.F55_82.value);

	// ---------------------------------------------------
	// 9F36
	// ---------------------------------------------------
	setVal(cryptogramData.ATC, getDate("ss"));
	// ---------------------------------------------------
	// CVR from 9F10
	// ---------------------------------------------------
	/*
	 * EMV 96 Format - Key Derivation Index (1 Byte) - Cryptogram Version (1
	 * Byte) - CVR (4 bytes) - DAC (2 bytes)
	 */

	/*
	 * EMV 2000 Format - Key Derivation Index (1 Byte) - Cryptogram Version (1
	 * Byte) - CVR (6 bytes) - DAC (2 bytes) - Plaintext/Encrypted Couters (8
	 * bytes)
	 */

	if (currentCard.EMVStandard.value === "**MC96**")
		setVal(cryptogramData.CVR, acquirerDataFromCsv.F55_9F10.value.slice(5, 12));// not
	// sure!!![5:12]

	else if (currentCard.EMVStandard.value === "**VISA96**")
		setVal(cryptogramData.CVR, acquirerDataFromCsv.F55_9F10.value.slice(7, 14));// not
	// sure!!![7:14]

	else
		setVal(cryptogramData.CVR, acquirerDataFromCsv.F55_9F10.value.slice(5, 16));// not
	// sure!!![5:16]

	printLine('cryptogramData.ATC:' + cryptogramData.ATC.value);

	setVal(cryptogramData.ARQCInputData, cryptogramData.Amount.value + // 9F02
		cryptogramData.AmountOther.value + // 9F03
		cryptogramData.CtryCode.value + // 9F1A
		getBase10(cryptogramData.TVR.value) + // 95
		cryptogramData.CncyCode.value + // 5F2A
		getBase10(cryptogramData.TxnDate.value) + // 9A
		getBase10(cryptogramData.TxnType.value) + // 9C
		getBase10(cryptogramData.UN.value) + // 9F37
		getBase10(cryptogramData.AIP.value) + // 82
		getBase10(cryptogramData.ATC.value) + // 9F36
		getBase10(cryptogramData.CVR.value));// CVR from 9F10

	var seqNumber = cryptogramData.PanSequenceNumber.value;
	// printLine('ARQC InputDAta:' + cryptogramData.ARQCInputData.value)

	var panNPadded = "0000000000" + cryptogramData.PAN.value;
	panNPadded = panNPadded.substring(panNPadded.length - 14);
	var seqNPadded = "0" + seqNumber;
	seqNPadded = seqNPadded.substring(seqNPadded.length - 2);
	var panSeq = panNPadded + seqNPadded;
	printLine("EMVStandard:" + currentCard.EMVStandard.value);

	// algorythm is determined automatically by Scheme=VISA and
	// CVN=TAG_9F10[5:6]
	// If CVN is 0A, we're using the VISA96 Algorithm for key method.
	// If CVN is 0E, we're using the EMV2000 Algorithm.
	// // If CVN is 11, 12, we're using the VISA96 Algorithm.
	if ((currentCard.EMVStandard.value === "**EMV2000**") || (currentCard.EMVStandard.value === "**VISA96**")) {
		printLine('currentKey.EMV2000MKPartOne.value:' + currentKey.EMV2000MKPartOne.value);
		printLine('currentKey.EMV2000MKPartTwo.value:' + currentKey.EMV2000MKPartTwo.value);
		cryptogramData.MK.value = currentKey.EMV2000MKPartOne.value + currentKey.EMV2000MKPartTwo.value + '';

		cryptogramData.IV.value = currentKey.InitVectorPartOne.value + currentKey.InitVectorPartTwo.value + '';

		var udkA = setOddParity(encrypt(panSeq, cryptogramData.MK.value));
		var udkB = setOddParity(encrypt(getChar(bitXOR(getBits(panSeq), getBits("FFFFFFFFFFFFFFFF"))), cryptogramData.MK.value));
		var iv = currentKey.InitVectorPartOne.value + currentKey.InitVectorPartTwo.value;
		var sessionKey = emvSessionKey(udkA + udkB, cryptogramData.ATC.value, iv);
		var arqc = calculate_emv_2000_arqc(cryptogramData.ARQCInputData.value + "80", sessionKey);
		setVal(cryptogramData.GeneratedArqc, arqc);
		printLine("arqc here:" + arqc)
	} else if (currentCard.EMVStandard === "**MC96**") {

		cryptogramData.MK.value = currentKey.MC96MKPartOne.value, currentKey.MC96MKPartTwo.value;

		cryptogramData.ARQC.value = calculate_mc_96_arqc()
	} else {
		// cryptogramData.MK.value = currentKey.VISA96MKPartOne.value,
		// currentKey.VISA96MKPartTwo.value
		//
		// cryptogramData.GeneratedArqc.value =
		// generateArqc(cryptogramData.PAN.value,
		// cryptogramData.PanSequenceNumber.value, cryptogramData.MK.value,
		// cryptogramData.ARQCInputData.value, "VISA96")
		//
		// printLine("| ENCRYPTION : " + TimeNow + " ARQC input Data [",
		// cryptogramData.ARQCInputData.value, "]")
		// printLine("| ENCRYPTION : " + TimeNow + " PAN [",
		// cryptogramData.PAN.value,
		// "]")
		// printLine("| ENCRYPTION : " + TimeNow + " Seq [",
		// cryptogramData.PanSequenceNumber, "]")
		// printLine("| ENCRYPTION : " + TimeNow + " MK [", cryptogramData.MK,
		// "]")
		// printLine("| ENCRYPTION : " + TimeNow + " Generated VISA96 ARQC [",
		// cryptogramData.GeneratedArqc, "]")
	}

	return cryptogramData;
}

// build_F56_OriginalDataElements(acquirerDataFromCsv);
function build_F56_OriginalDataElements(acquirerDataFromCsv) {
	if (acquirerDataFromCsv.F56_OriginalDataElements.value === "**NOVALUE**") {
		return;
	} else if (acquirerDataFromCsv.F56_OriginalDataElements.value === "**SYSTEM**") {

		F56.MessageType.value = "0000";
		F56.F11_SystemTraceAuditNumber.value = "000000";
		F56.F12_DateTimeLocalTransaction.value = "000000000000";
		F56.F32_AcquiringInstitutionIdentificationCode.value = "00";

		if (previousisoMessageAcqRq.MessageType.value !== "")
			setVal(F56.MessageType, previousisoMessageAcqRq.MessageType.value)

		if (previousisoMessageAcqRq.F11_SystemTraceAuditNumber.value !== "")
			setVal(F56.F11_SystemTraceAuditNumber, previousisoMessageAcqRq.F11_SystemTraceAuditNumber.value)

		if (previousisoMessageAcqRq.F12_DateTimeLocalTransaction.value !== "")
			setVal(F56.F12_DateTimeLocalTransaction, previousisoMessageAcqRq.F12_DateTimeLocalTransaction.value)

		if (previousisoMessageAcqRq.F32_AcquiringInstitutionIdentificationCode.value !== "")
			setVal(F56.F32_AcquiringInstitutionIdentificationCode, previousisoMessageAcqRq.F32_AcquiringInstitutionIdentificationCode.value);

		setVal(isoMessageAcqRq.F56_OriginalDataElements, F56)
	} else
		isoMessageAcqRq.F56_OriginalDataElements.value = acquirerDataFromCsv.F56_OriginalDataElements.value;
	setBitON(isoMessageAcqRq.F56_OriginalDataElements.bitmap_position)
}

